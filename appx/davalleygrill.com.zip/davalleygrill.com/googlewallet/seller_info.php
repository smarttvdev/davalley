<?php
/**
* Provide merchant information here.
*
* @copyright 2013 Google Inc. All rights reserved.
* @author Rohit Panwar <panwar@google.com>
*/

class SellerInfo {
  /**
  * @var string Merchant id.
  */
  public static $issuerId = "Merchant Account Id";
  
  /**
  * @var string Merchant secret key.
  */
  public static $secretKey = "Merchant Account Secret Key";
}