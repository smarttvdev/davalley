<?php
include("include/head.php");
require_once("authorize.net/AuthorizeNet.php");
$get_payment_info = $obj->get_payment_info($_SESSION['order_id']);
$get_order_info = $obj->get_current_order_detail();
$CONFIG['AUTHORIZENET_SANDBOX'] = TRUE;
$CONFIG['loginID'] = '5bJRn256f6'; // login
$CONFIG['transactionKey'] = '226349jmxLqSw7L7'; // transactionKey
// END AUTHORIZE.NET CONFIG //
$CONFIG['site'] = base_url();
$CONFIG['image_location'] = "/images/products";
$CONFIG['company'] = "Da ValleyGrill";
$CONFIG['company_slogan'] = "Hawaiian style Asian Fusion ... Mon-Fri 9am-7:30pm  Sat 9-3pm";
$CONFIG['pageRows'] = 10;
$CONFIG['x_relay_url'] = $CONFIG['site'] . 'card_payment_info.php';
$CONFIG['AUTHORIZE_MD5_HASH'] = '16931504cd2a6403e8a7f9d951e04e98';
$CONFIG['state_tax'] = "8.6%";
$CONFIG['menu_url'] = $CONFIG['site'] . "/images/menu.png";


$url			= $CONFIG['AUTHORIZENET_SANDBOX'] ? AuthorizeNetDPM::SANDBOX_URL : AuthorizeNetDPM::LIVE_URL;
$loginID		= $CONFIG['loginID'];
$transactionKey 	= $CONFIG['transactionKey'];
$amount 		= $obj->get_order_total_amount()-$get_payment_info['tendered_amt'];
$description 		= "Transaction Order for " . $CONFIG['company'];
$label 			= "Checkout"; // The is the label on the 'submit' button
$testMode		= "false"; // authorize.net test mode
//$invoice	= date(YmdHis);
$invoice = $_SESSION['order_id'];
$time = time();
$fp_sequence = $time;
if( phpversion() >= '5.1.2' )
	$fingerprint = hash_hmac("md5", $loginID . "^" . $fp_sequence . "^" . $time . "^" . $amount . "^", $transactionKey); 
else 
	$fingerprint = bin2hex(mhash($CONFIG['AUTHORIZE_MD5_HASH'], $loginID . "^" . $fp_sequence . "^" . $time . "^" . $amount . "^", $transactionKey));

?>
					<form id='checkOutSubmit' method='post' action='<?php echo $url; ?>' >				   
						<input type='hidden' name='x_login' value='<?php echo $loginID; ?>' />
						<input type='hidden' name='x_amount' value='<?php echo $amount; ?>' />
						<input type='hidden' name='x_description' value='<?php echo $description; ?>' />
						<input type='hidden' name='x_invoice_num' value='<?php echo $invoice; ?>' />
						<input type='hidden' name='x_fp_sequence' value='<?php echo $fp_sequence; ?>' />
						<input type='hidden' name='x_fp_timestamp' value='<?php echo $time; ?>' />
						<input type='hidden' name='x_fp_hash' value='<?php echo $fingerprint; ?>' />
						<input type='hidden' name='x_test_request' value='<?php echo$testMode; ?>' />
						<input type='hidden' name='x_show_form' value='PAYMENT_FORM' />
						<input type='hidden' name='x_receipt_link_method' id='x_receipt_link_method' value='post' />
						<input type="hidden" name="x_receipt_link_url" value="<?php echo $CONFIG['x_relay_url']; ?>" >
						<input type='hidden' name='x_relay_response' value='true' />
						<input type='hidden' name='x_relay_url' value="<?php echo $CONFIG['x_relay_url']; ?>"/>
						<input type='hidden' name='x_cust_id' id='x_cust_id' value='<?php echo $get_order_info['ticket_id']; ?>' />  

						<INPUT TYPE='hidden' name='x_version' VALUE='3.1' />
						<!-- Swipe Details -->
						<INPUT TYPE='hidden' name='x_first_name' id='x_first_name' VALUE='' />
						<INPUT TYPE='hidden' name='x_last_name' id='x_last_name' VALUE='' />
						<INPUT TYPE='hidden' name='x_card_num' id='x_card_num' VALUE='' />
						<INPUT TYPE='hidden' name='x_exp_date' id='x_exp_date' VALUE='' />
						<INPUT TYPE='hidden' name='x_card_code' id='x_card_code' VALUE='' />

<?php
$i=1;
$get_order_items = $obj->get_order_item_list_checkout($_SESSION['order_id']);
foreach($get_order_items as $order){
	echo "<INPUT TYPE='HIDDEN' name='x_line_item' VALUE='".$i."<|>".substr(($order['itemName']),0,30)."<|>".substr(($order['itemDescription']),0,30)."<|>".$order['quantity']."<|>".$order['itemPrice']."<|>Y'>\n";
	if($order['item_discount_amount']>0){
	echo "<INPUT TYPE='HIDDEN' name='x_line_item' VALUE='".$i."<|>".substr(($order['item_discount_percent']),0,30)."% Discount<|><|>".$order['quantity']."<|>".$order['item_discount_amount']."<|>Y'>\n";
	}
	$i++;
}
?>
						<INPUT TYPE='HIDDEN' name='x_tax' VALUE='Tax<|>state tax<|><?php echo $obj->get_tax_amount(); ?>'>
						<INPUT TYPE='HIDDEN' name='x_duty' VALUE='Tip<|>     Tip<|><?php echo $get_payment_info['tip_amt']; ?>'>
						<input type='submit' id='checkoutbtn' class='button button2' value='<?php echo $label; ?>'>
	
					</form>
<?php
include("include/footer.php");
?>