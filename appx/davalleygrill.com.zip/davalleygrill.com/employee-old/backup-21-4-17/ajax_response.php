<?php
include('classes.php');
$obj=new Classes();
/*Login*/
if(isset($_REQUEST['login'])){
$uname   =	$_POST['username'];
$passwrd =	$_POST['password'];
echo $row=$obj->login($uname,$passwrd);
}
/**/
/*New Order*/
if(isset($_REQUEST['create_new_order'])){
	$create_order = $obj->create_new_order($_REQUEST['table_number']);
	$_SESSION['order_id'] = $create_order;
	if($create_order!=""){
		echo "1";
	}else{
		echo "0";
	}
}
/*New Order*/


if(isset($_REQUEST['add_to_cart'])){
	$add_item_to_order = $obj->add_item_to_order($_REQUEST['add_to_cart']);
	if($add_item_to_order=="exist"){
		echo "exist";
	}else{
    $get_total_order_item = $obj->get_total_order_item();
	echo $order_item_list = '<tr id="item_row_'.$add_item_to_order["itemID"].'"><td class="text-center"><span>'.$get_total_order_item.'</span></td><td>'.$add_item_to_order["itemCode"].'</td><td class="_title">'.$add_item_to_order["itemName"].'<br><span>'.$add_item_to_order["itemDescription"].'</span></td><td class="QTY"><div class="input-group"><span class="input-group-btn"><button type="button" class="quantity-left-minus btn btn-number"  data-type="minus" data-field="" onclick="quantity_minus('.$add_item_to_order["itemID"].')"><span class="glyphicon glyphicon-minus"></span></button></span><input type="text" id="quantity_'.$add_item_to_order["itemID"].'" name="quantity" class="form-control input-number" value="1" min="1" max="100"><span class="input-group-btn"><button type="button" class="quantity-right-plus btn  btn-number" data-type="plus" data-field="" onclick="quantity_plus('.$add_item_to_order["itemID"].')"><span class="glyphicon glyphicon-plus"></span></button></span></div></td><td><span id="item_total_price_'.$add_item_to_order["itemID"].'">'.$add_item_to_order["itemPrice"].'</span><span style="display:none;" id="original_item_price_'.$add_item_to_order["itemID"].'">'.$add_item_to_order["itemPrice"].'</span></td><td class="remove"><a href="javascript:void(0)" onclick="remove_item_from_order('.$add_item_to_order["itemID"].')"><i class="fa fa-trash" aria-hidden="true"></i></a></td></tr>';
	?>
	
	<?php	
	}
	
	/*$get_item_by_id = $obj->get_item_by_id($_REQUEST['add_to_cart']);
	//print_r($get_item_by_id);
	$item_row = 
	$_SESSION['cart_items'][] = $item_row;
	$resp_arr = array('item_row' => $item_row, 'total' => '0');
	echo json_encode($resp_arr);*/
}


/*Update Quantity*/

if(isset($_REQUEST['update_qty'])){
	$update_item_qty = $obj->update_item_qty($_REQUEST['item_id'],$_REQUEST['qty']);
	echo $obj->get_order_total_amount();
}

/*Update Quantity*/
/*Remove Item from  Order*/
if(isset($_REQUEST['remove_item_from_order'])){
    $remove_item_from_order = $obj->remove_item_from_order($_REQUEST['id']);
    echo $obj->get_order_total_amount();
}
/*Remove Item from  Order*/

/*Get Total amount For add to cart*/

if(isset($_REQUEST['get_total_for_add_to_cart'])){
    //$update_item_qty = $obj->update_item_qty($_REQUEST['item_id'],$_REQUEST['qty']);
    echo $obj->get_order_total_amount();
}

/*Get Total amount For add to cart*/

/*Make First Order*/
if(isset($_REQUEST['make_first_order'])){
	echo $_SESSION['order_id'] = $_REQUEST['id'];
}
/*Make First Order*/


/*Edit Order*/

if(isset($_REQUEST['edit_order_from_front'])){
	echo $edit_order_from_front = $obj->edit_order_from_front($_REQUEST['id']);
}

/*Edit Order*/


/*save_order_payment*/

if(isset($_REQUEST['save_order_payment'])){
	$order_payment = $obj->save_order_payment($_POST);
}

/*save_order_payment*/
?>