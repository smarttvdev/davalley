<?php
//$mysqli = new mysqli("localhost", "davalley", "Newpass1#", "davalley");
$mysqli = new mysqli("localhost", "myorders", "Davalley7!", "myorders");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
#echo $mysqli->host_info . "\n";
 
?>
