      <h2>Our Blog</h2>
      <div class="page-content">
        
        <div class="blog-article">
          <div class="article-header">
            <p class="title">This is the article's title</p>
            <p class="info">26 August 2012 <span>(John Doe)</span></p>
          </div>
          <div class="article-body">
            <div class="text">
              <img alt="Image-alt" src="http://techzinia.com/lab/davalleygrill/images/blog-icon2.png" />
              <p>Influential and inspirational in equal measure, Barzan Publishing's attractive fusion of retail and lifestyle is changing the way shopping is perceived, making Barzan Publishing not just a destination... but a revelation.</p>
              <p>Barzan Publishing has emerged as the place to be seen for those who value a touch of class. For global brands, Barzan Publishing offers pristine, picture-perfect surroundings and an attractive client base. </p>
            </div>
          </div>
          <div class="article-footer">
            <a href="#" class="button button2 left">Read On</a>
            <div class="social right">
              <span class='st_fblike_hcount'></span>
              <span class='st_twitter_hcount'></span>
            </div>
            <div class="clear"></div>
          </div>
        </div>        
        <div class="blog-article">
          <div class="article-header">
            <p class="title">This is the article's title</p>
            <p class="info">22 August 2012 <span>(John Doe)</span></p>
          </div>
          <div class="article-body">
            <div class="text">
              <img alt="Image-alt" src="http://techzinia.com/lab/davalleygrill/images/blog-icon.png" />
              <p>Influential and inspirational in equal measure, Barzan Publishing's attractive fusion of retail and lifestyle is changing the way shopping is perceived, making Barzan Publishing not just a destination... but a revelation.</p>
              <p>Barzan Publishing has emerged as the place to be seen for those who value a touch of class. For global brands, Barzan Publishing offers pristine, picture-perfect surroundings and an attractive client base. </p>
            </div>
          </div>
          <div class="article-footer">
            <a href="#" class="button button2 left">Read On</a>
            
            <div class="social right">
              <span class='st_fblike_hcount'></span>
              <span class='st_twitter_hcount'></span>
            </div>

            <!--<div class="social right">
              <span class='st_fblike_hcount addthis-button'></span>
              <span class='st_twitter_hcount addthis-button'></span>
            </div>-->
            <div class="clear"></div>
          </div>
        </div>
        
      </div>
