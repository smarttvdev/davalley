<?php
session_start();
include_once("../SMS_Module/classes/config.php");
?>
    <h2>Payment Error!</h2>
    <div class="error">
      <h3>We're sorry, but we can't process your order at this time ! You haven't been charged.</h3>
    </div>

   <div class="divider"></div>
   <a href="#">Back</a>
        