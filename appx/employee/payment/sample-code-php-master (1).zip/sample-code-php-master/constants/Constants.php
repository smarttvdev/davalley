<?php
namespace SampleCode;

class Constants
{
	//merchant credentials
	const MERCHANT_LOGIN_ID = "5KP3u95bQpv";
	const MERCHANT_TRANSACTION_KEY = "346HZ32z3fP4hTG2";
	
	const RESPONSE_OK = "Ok";
	
	//Recurring Billing
	const SUBSCRIPTION_ID_GET = "2930242";

	//Transaction Reporting
	const TRANS_ID = "2238968786";

	const SAMPLE_AMOUNT = "2.23";
}
?>

