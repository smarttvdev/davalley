<?php
$dbh = new PDO("mysql:dbname=test;host=127.0.0.1;port=3306", "root", "backstreetboys");
