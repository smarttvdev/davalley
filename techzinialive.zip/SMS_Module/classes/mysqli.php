<?php
$mysqli = new mysqli("davalley.db.11874827.hostedresource.com", "davalley", "Newpass1#", "davalley");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
#echo $mysqli->host_info . "\n";
 
?>